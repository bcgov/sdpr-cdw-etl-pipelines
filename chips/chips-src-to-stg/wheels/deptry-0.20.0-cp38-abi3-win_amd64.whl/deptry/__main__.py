from __future__ import annotations

from deptry.cli import deptry

deptry()
